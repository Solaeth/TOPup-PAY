const BOT_TOKEN = import.meta.env.VITE_TELEGRAM_BOT_TOKEN as string
const CHAT_ID = import.meta.env.VITE_TELEGRAM_CHAT_ID as string

export async function notifyNewOrder(opts: {
  orderId: string
  platform: string
  coins: number
  accountId: string
  amountUsdc: string
}) {
  if (!BOT_TOKEN || !CHAT_ID) return
  const text =
    `🛒 *New Order #${opts.orderId}*\n` +
    `Platform: ${opts.platform}\n` +
    `Coins: ${opts.coins}\n` +
    `Account: \`${opts.accountId}\`\n` +
    `Amount: $${opts.amountUsdc} USDC`
  try {
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: CHAT_ID, text, parse_mode: 'Markdown' }),
    })
  } catch {
    // Notification failure is non-critical — order already placed onchain
  }
}
