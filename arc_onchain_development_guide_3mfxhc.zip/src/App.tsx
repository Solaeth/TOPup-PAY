import { useState } from 'react'
import { useAccount, useReadContract } from 'wagmi'
import { Store, LayoutDashboard } from 'lucide-react'
import StoreFront from '@/components/StoreFront'
import AdminDashboard from '@/components/AdminDashboard'

// ---------------------------------------------------------------------------
// Paste your deployed contract address here after running:
//   "Deploy contract" in Arc Studio
// ---------------------------------------------------------------------------
const CONTRACT_ADDRESS: `0x${string}` | null = '0xe49d90b0c54766302465d3bfb42f8b1ff7578330'

// ABI — matches SocialTopUp.sol
const CONTRACT_ABI = [
  // Products
  { name: 'addProduct', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'name', type: 'string' }, { name: 'platform', type: 'string' }, { name: 'priceUsdc', type: 'uint256' }], outputs: [] },
  { name: 'updateProduct', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'productId', type: 'uint256' }, { name: 'newPrice', type: 'uint256' }, { name: 'active', type: 'bool' }], outputs: [] },
  { name: 'updateProductFull', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'productId', type: 'uint256' }, { name: 'name', type: 'string' }, { name: 'platform', type: 'string' }, { name: 'newPrice', type: 'uint256' }, { name: 'active', type: 'bool' }], outputs: [] },
  { name: 'getProduct', type: 'function', stateMutability: 'view', inputs: [{ name: 'productId', type: 'uint256' }], outputs: [{ type: 'tuple', components: [{ name: 'id', type: 'uint256' }, { name: 'name', type: 'string' }, { name: 'platform', type: 'string' }, { name: 'priceUsdc', type: 'uint256' }, { name: 'active', type: 'bool' }] }] },
  { name: 'productCount', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  // Orders
  { name: 'placeOrder', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'productId', type: 'uint256' }, { name: 'buyerAccountId', type: 'string' }, { name: 'quantity', type: 'uint256' }], outputs: [] },
  { name: 'confirmDelivery', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'orderId', type: 'uint256' }], outputs: [] },
  { name: 'refundOrder', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'orderId', type: 'uint256' }], outputs: [] },
  { name: 'cancelExpiredOrder', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'orderId', type: 'uint256' }], outputs: [] },
  { name: 'getOrder', type: 'function', stateMutability: 'view', inputs: [{ name: 'orderId', type: 'uint256' }], outputs: [{ type: 'tuple', components: [{ name: 'id', type: 'uint256' }, { name: 'buyer', type: 'address' }, { name: 'productId', type: 'uint256' }, { name: 'amount', type: 'uint256' }, { name: 'status', type: 'uint8' }, { name: 'createdAt', type: 'uint256' }, { name: 'buyerAccountId', type: 'string' }] }] },
  { name: 'orderCount', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { name: 'getOrdersByBuyer', type: 'function', stateMutability: 'view', inputs: [{ name: 'buyer', type: 'address' }], outputs: [{ type: 'uint256[]' }] },
  // Admin
  { name: 'setTreasury', type: 'function', stateMutability: 'nonpayable', inputs: [{ name: 'newTreasury', type: 'address' }], outputs: [] },
  { name: 'pause', type: 'function', stateMutability: 'nonpayable', inputs: [], outputs: [] },
  { name: 'unpause', type: 'function', stateMutability: 'nonpayable', inputs: [], outputs: [] },
  // Events
  { name: 'OrderPlaced', type: 'event', inputs: [{ name: 'orderId', type: 'uint256', indexed: true }, { name: 'buyer', type: 'address', indexed: true }, { name: 'productId', type: 'uint256', indexed: false }, { name: 'amount', type: 'uint256', indexed: false }, { name: 'buyerAccountId', type: 'string', indexed: false }] },
  { name: 'OrderDelivered', type: 'event', inputs: [{ name: 'orderId', type: 'uint256', indexed: true }] },
  { name: 'OrderRefunded', type: 'event', inputs: [{ name: 'orderId', type: 'uint256', indexed: true }] },
] as const

type View = 'store' | 'admin'

const OWNER_ABI = [
  { name: 'owner', type: 'function', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] },
] as const

function AppInner() {
  const [view, setView] = useState<View>('store')
  const { address } = useAccount()

  // Read the contract owner onchain
  const { data: ownerAddress } = useReadContract(
    CONTRACT_ADDRESS
      ? { address: CONTRACT_ADDRESS, abi: OWNER_ABI, functionName: 'owner', chainId: 5042002 }
      : undefined
  )

  const isOwner =
    address && ownerAddress
      ? address.toLowerCase() === (ownerAddress as string).toLowerCase()
      : false

  // If viewing admin but not owner, fall back to store
  const activeView: View = view === 'admin' && !isOwner ? 'store' : view

  return (
    <div className="min-h-dvh pb-24">
      {activeView === 'store' ? (
        <StoreFront contractAddress={CONTRACT_ADDRESS} contractAbi={CONTRACT_ABI} />
      ) : (
        <AdminDashboard contractAddress={CONTRACT_ADDRESS} contractAbi={CONTRACT_ABI} />
      )}

      {/* Bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 flex justify-center" style={{ zIndex: 40 }}>
        <div
          className="mx-4 mb-4 flex w-full max-w-md items-center gap-1 rounded-2xl p-1.5"
          style={{ background: 'rgba(13,27,47,0.82)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)', border: '1px solid rgba(255,255,255,0.12)', boxShadow: '0 4px 24px rgba(0,0,0,0.40)' }}
        >
          <button
            onClick={() => setView('store')}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold transition-all"
            style={activeView === 'store'
              ? { background: 'var(--accent)', color: '#0d1b2f' }
              : { background: 'rgba(255,255,255,0.07)', color: 'var(--muted)', border: '1px solid rgba(255,255,255,0.13)' }}
          >
            <Store className="size-4" />
            Shop
          </button>

          {isOwner && (
            <button
              onClick={() => setView('admin')}
              className="flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold transition-all"
              style={activeView === 'admin'
                ? { background: 'var(--accent)', color: '#0d1b2f' }
                : { background: 'rgba(255,255,255,0.07)', color: 'var(--muted)', border: '1px solid rgba(255,255,255,0.13)' }}
            >
              <LayoutDashboard className="size-4" />
              Admin
            </button>
          )}
        </div>
      </nav>
    </div>
  )
}

export default function App() {
  return <AppInner />
}
