import { useState, useCallback } from 'react'
import { useAccount, useReadContract, useWriteContract, useWaitForTransactionReceipt, useSwitchChain } from 'wagmi'
import { ConnectKitButton } from 'connectkit'
import { Plus, CheckCircle, XCircle, Loader2, Package, ClipboardList, Settings, ChevronRight, Pencil, Check, X, Copy } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { getUsdc } from '@/onchain-facts'
import { Amount } from '@/onchain-money'
import { parseUnits } from 'viem'

const ARC_TESTNET_ID = 5042002
const usdcFact = getUsdc(ARC_TESTNET_ID)!

const glass = {
  card: {
    background: 'rgba(26,47,74,0.80)',
    backdropFilter: 'blur(24px) saturate(160%)',
    WebkitBackdropFilter: 'blur(24px) saturate(160%)',
    border: '1px solid rgba(172,198,233,0.22)',
    boxShadow: '0 8px 40px rgba(0,0,0,0.40), inset 0 1px 0 rgba(172,198,233,0.10)',
  } as React.CSSProperties,
  inner: {
    background: 'rgba(13,27,47,0.60)',
    border: '1px solid rgba(172,198,233,0.18)',
  } as React.CSSProperties,
}

type OrderStatus = 'Pending' | 'Delivered' | 'Refunded'

interface Order {
  id: bigint
  buyer: `0x${string}`
  productId: bigint
  amount: bigint
  status: number
  createdAt: bigint
  buyerAccountId: string
}

const STATUS_LABELS: OrderStatus[] = ['Pending', 'Delivered', 'Refunded']

const STATUS_STYLE: Record<OrderStatus, { bg: string; text: string }> = {
  Pending:   { bg: 'rgba(255,205,131,0.25)', text: '#b45309' },
  Delivered: { bg: 'rgba(26,128,71,0.12)',   text: '#1a8047' },
  Refunded:  { bg: 'rgba(186,43,76,0.10)',   text: '#ba2b4c' },
}

interface AdminDashboardProps {
  contractAddress: `0x${string}` | null
  contractAbi: readonly object[]
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false)
  const handleCopy = useCallback(() => {
    void navigator.clipboard.writeText(text).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    })
  }, [text])
  return (
    <button
      onClick={(e) => { e.stopPropagation(); handleCopy() }}
      title="Copy"
      className="inline-flex items-center justify-center rounded-lg p-1 transition-all"
      style={{ background: copied ? 'rgba(74,222,128,0.15)' : 'rgba(255,255,255,0.07)', color: copied ? '#4ade80' : '#93c5fd', border: '1px solid rgba(100,160,255,0.20)' }}
    >
      {copied ? <Check className="size-3" /> : <Copy className="size-3" />}
    </button>
  )
}

export default function AdminDashboard({ contractAddress, contractAbi }: AdminDashboardProps) {
  const { chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const wrongChain = chainId !== ARC_TESTNET_ID
  const [tab, setTab] = useState<'orders' | 'products'>('orders')

  return (
    <div className="relative min-h-dvh overflow-hidden" style={{ background: 'var(--bg-gradient)' }}>
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div style={{ position: 'absolute', top: '4%', right: '6%', width: 320, height: 320, borderRadius: '50%', background: 'radial-gradient(circle, rgba(172,198,233,0.16) 0%, transparent 70%)', filter: 'blur(80px)' }} />
        <div style={{ position: 'absolute', bottom: '15%', left: '4%', width: 240, height: 240, borderRadius: '50%', background: 'radial-gradient(circle, rgba(95,190,255,0.10) 0%, transparent 70%)', filter: 'blur(65px)' }} />
      </div>

      <div className="relative z-10 mx-auto max-w-md px-4 pb-32 pt-6">
        {/* Header */}
        <header className="mb-6 flex items-center justify-between">
          <div>
            <p className="display text-xl font-bold" style={{ color: 'var(--ink)' }}>Admin</p>
            <p className="text-xs" style={{ color: 'var(--subtle)' }}>Manage orders and products</p>
          </div>
          <ConnectKitButton.Custom>
            {({ isConnected, show, address: addr }) => (
              <button
                onClick={show}
                className="rounded-full px-4 py-2 text-xs font-semibold"
                style={{ background: 'var(--accent)', color: '#0d1b2f', border: '1px solid rgba(172,198,233,0.40)' }}
              >
                {isConnected && addr ? `${addr.slice(0, 6)}…${addr.slice(-4)}` : 'Connect'}
              </button>
            )}
          </ConnectKitButton.Custom>
        </header>

        {/* Tab switcher */}
        <div className="mb-5 flex gap-2 rounded-2xl p-1" style={glass.inner}>
          {(['orders', 'products'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className="flex-1 rounded-xl py-2 text-sm font-semibold capitalize transition-all"
              style={tab === t ? { background: 'var(--accent)', color: 'white' } : { color: 'var(--muted)' }}
            >
              {t === 'orders' ? 'Orders' : 'Products'}
            </button>
          ))}
        </div>

        {!contractAddress ? (
          <section className="rounded-3xl p-6 text-center" style={glass.card}>
            <Settings className="mx-auto mb-3 size-8" style={{ color: 'var(--subtle)' }} />
            <p className="display font-bold" style={{ color: 'var(--ink)' }}>Contract not deployed</p>
            <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Deploy SocialTopUp first.</p>
          </section>
        ) : (
          <AnimatePresence mode="wait">
            {tab === 'orders' ? (
              <motion.div key="orders" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                <OrdersPanel contractAddress={contractAddress} contractAbi={contractAbi} wrongChain={wrongChain} onSwitchChain={() => switchChain({ chainId: ARC_TESTNET_ID })} />
              </motion.div>
            ) : (
              <motion.div key="products" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
                <ProductsPanel contractAddress={contractAddress} contractAbi={contractAbi} wrongChain={wrongChain} onSwitchChain={() => switchChain({ chainId: ARC_TESTNET_ID })} />
              </motion.div>
            )}
          </AnimatePresence>
        )}
      </div>
    </div>
  )
}

function OrdersPanel({ contractAddress, contractAbi, wrongChain, onSwitchChain }: {
  contractAddress: `0x${string}`
  contractAbi: readonly object[]
  wrongChain: boolean
  onSwitchChain: () => void
}) {
  const { data: orderCountRaw, refetch: refetchCount, isLoading } = useReadContract({
    address: contractAddress,
    abi: contractAbi,
    functionName: 'orderCount',
    chainId: ARC_TESTNET_ID,
    query: { refetchInterval: 4000, staleTime: 0 },
  })

  const count = orderCountRaw !== undefined ? Number(orderCountRaw) : null
  // newest first, show all orders
  const orderIds = count !== null && count > 0
    ? Array.from({ length: count }, (_, i) => BigInt(count - i))
    : []

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold tracking-widest" style={{ color: 'var(--muted)', letterSpacing: '0.08em' }}>
          ALL ORDERS {count !== null ? `(${count})` : ''}
        </p>
        <button
          onClick={() => void refetchCount()}
          className="rounded-xl px-3 py-1.5 text-xs font-semibold flex items-center gap-1"
          style={{ background: 'rgba(255,255,255,0.07)', color: '#93c5fd', border: '1.5px solid rgba(100,160,255,0.25)' }}
        >
          {isLoading ? <Loader2 className="size-3 animate-spin" /> : '↻'} Refresh
        </button>
      </div>
      {count === null && (
        <div className="flex justify-center py-8"><Loader2 className="size-6 animate-spin" style={{ color: 'var(--accent)' }} /></div>
      )}
      {count === 0 && (
        <section className="rounded-3xl p-6 text-center" style={glass.card}>
          <ClipboardList className="mx-auto mb-3 size-8" style={{ color: 'var(--subtle)' }} />
          <p className="font-semibold" style={{ color: 'var(--ink)' }}>No orders yet</p>
          <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Orders from buyers will appear here.</p>
        </section>
      )}
      {orderIds.map((id) => (
        <OrderRow
          key={id.toString()}
          orderId={id}
          contractAddress={contractAddress}
          contractAbi={contractAbi}
          wrongChain={wrongChain}
          onSwitchChain={onSwitchChain}
        />
      ))}
    </div>
  )
}

function OrderRow({ orderId, contractAddress, contractAbi, wrongChain, onSwitchChain }: {
  orderId: bigint
  contractAddress: `0x${string}`
  contractAbi: readonly object[]
  wrongChain: boolean
  onSwitchChain: () => void
}) {
  const [expanded, setExpanded] = useState(false)

  const { data: raw, refetch } = useReadContract({
    address: contractAddress,
    abi: contractAbi,
    functionName: 'getOrder',
    args: [orderId],
    chainId: ARC_TESTNET_ID,
  })

  const { data: productRaw } = useReadContract({
    address: contractAddress,
    abi: contractAbi,
    functionName: 'getProduct',
    args: raw ? [(raw as Order).productId] : undefined,
    chainId: ARC_TESTNET_ID,
    query: { enabled: !!raw },
  })

  const { writeContract: confirm, data: confirmHash, isPending: confirmPending } = useWriteContract()
  const { writeContract: refund, data: refundHash, isPending: refundPending } = useWriteContract()
  const { isLoading: confirmLoading, isSuccess: confirmSuccess } = useWaitForTransactionReceipt({ hash: confirmHash })
  const { isLoading: refundLoading, isSuccess: refundSuccess } = useWaitForTransactionReceipt({ hash: refundHash })

  if (confirmSuccess || refundSuccess) void refetch()

  if (!raw) return null
  const order = raw as Order
  const product = productRaw as { name: string; platform: string } | undefined
  const statusLabel = STATUS_LABELS[order.status] ?? 'Unknown'
  const style = STATUS_STYLE[statusLabel] ?? { bg: 'var(--surface-muted)', text: 'var(--muted)' }
  const amountFormatted = Amount.fromRaw(order.amount, usdcFact.decimals).toFixed(2)
  // Parse "username [500 coins]" → username and coinCount
  const coinMatch = order.buyerAccountId.match(/\[(\d+)\s/)
  const coinCount = coinMatch ? coinMatch[1] : null
  const usernameOnly = order.buyerAccountId.replace(/\s*\[\d+[^\]]*\]/, '').trim()
  const isPending = statusLabel === 'Pending'
  const isActing = confirmPending || confirmLoading || refundPending || refundLoading

  const handleConfirm = () => {
    if (wrongChain) { onSwitchChain(); return }
    confirm({ address: contractAddress, abi: contractAbi, functionName: 'confirmDelivery', args: [orderId], chainId: ARC_TESTNET_ID })
  }
  const handleRefund = () => {
    if (wrongChain) { onSwitchChain(); return }
    refund({ address: contractAddress, abi: contractAbi, functionName: 'refundOrder', args: [orderId], chainId: ARC_TESTNET_ID })
  }

  return (
    <div className="rounded-2xl overflow-hidden" style={glass.card}>
      <button className="w-full p-4 text-left" onClick={() => setExpanded(e => !e)}>
        <div className="flex items-center gap-3">
          <span className="mono text-xs font-medium" style={{ color: 'var(--subtle)' }}>#{orderId.toString()}</span>
          <div className="flex-1 min-w-0">
            {/* Product name + $ amount (no copy needed) */}
            <div className="flex items-center justify-between gap-2">
              <p className="font-semibold text-sm truncate" style={{ color: 'var(--ink)' }}>
                {product ? product.name : `Product #${order.productId}`}
              </p>
              <p className="display font-bold tabular-nums text-sm shrink-0" style={{ color: '#4ade80' }}>${amountFormatted}</p>
            </div>
            {/* Username (copy) + coin count (copy) + status */}
            <div className="flex items-center justify-between gap-2 mt-1">
              <div className="flex items-center gap-1.5 min-w-0 flex-wrap">
                <div className="flex items-center gap-1">
                  <p className="text-xs font-semibold truncate" style={{ color: 'var(--accent)' }}>{usernameOnly || '—'}</p>
                  {usernameOnly && <CopyButton text={usernameOnly} />}
                </div>
                {coinCount && (
                  <div className="flex items-center gap-1">
                    <p className="text-xs font-semibold" style={{ color: '#fbbf24' }}>{coinCount} coins</p>
                    <CopyButton text={coinCount} />
                  </div>
                )}
              </div>
              <span className="inline-block rounded-full px-2 py-0.5 text-xs font-semibold shrink-0" style={{ background: style.bg, color: style.text }}>{statusLabel}</span>
            </div>
            {/* Wallet address — small */}
            <p className="text-xs mt-0.5" style={{ color: 'var(--subtle)' }}>
              {order.buyer.slice(0, 8)}…{order.buyer.slice(-6)}
            </p>
          </div>
          <ChevronRight className="size-4 shrink-0 transition-transform" style={{ color: 'var(--subtle)', transform: expanded ? 'rotate(90deg)' : '' }} />
        </div>
      </button>

      <AnimatePresence>
        {expanded && isPending && (
          <motion.div
            initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 flex gap-2">
              <button
                disabled={isActing}
                onClick={handleConfirm}
                className="flex-1 flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold text-white disabled:opacity-50"
                style={{ background: 'var(--success)' }}
              >
                {confirmPending || confirmLoading ? <Loader2 className="size-4 animate-spin" /> : <CheckCircle className="size-4" />}
                Confirm delivery
              </button>
              <button
                disabled={isActing}
                onClick={handleRefund}
                className="flex-1 flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold text-white disabled:opacity-50"
                style={{ background: 'var(--danger)' }}
              >
                {refundPending || refundLoading ? <Loader2 className="size-4 animate-spin" /> : <XCircle className="size-4" />}
                Refund buyer
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

function ProductsPanel({ contractAddress, contractAbi, wrongChain, onSwitchChain }: {
  contractAddress: `0x${string}`
  contractAbi: readonly object[]
  wrongChain: boolean
  onSwitchChain: () => void
}) {
  const [showForm, setShowForm] = useState(false)
  const [name, setName] = useState('')
  const [platform, setPlatform] = useState('')
  const [price, setPrice] = useState('')

  const { data: productCountRaw, refetch: refetchCount } = useReadContract({
    address: contractAddress,
    abi: contractAbi,
    functionName: 'productCount',
    chainId: ARC_TESTNET_ID,
  })

  const { writeContract: addProduct, data: addHash, isPending: addPending } = useWriteContract()
  const { isLoading: addLoading, isSuccess: addSuccess } = useWaitForTransactionReceipt({ hash: addHash })

  if (addSuccess) { void refetchCount(); setShowForm(false); setName(''); setPrice('') }

  const handleAdd = () => {
    if (wrongChain) { onSwitchChain(); return }
    const priceRaw = parseUnits(price, usdcFact.decimals)
    addProduct({
      address: contractAddress,
      abi: contractAbi,
      functionName: 'addProduct',
      args: [name, platform, priceRaw],
      chainId: ARC_TESTNET_ID,
    })
  }

  const count = productCountRaw ? Number(productCountRaw) : 0
  const productIds = Array.from({ length: Math.min(count, 12) }, (_, i) => BigInt(i + 1))
  const isAdding = addPending || addLoading

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold tracking-widest" style={{ color: 'var(--muted)', letterSpacing: '0.08em' }}>PRODUCTS ({count})</p>
        <button
          onClick={() => setShowForm(s => !s)}
          className="flex items-center gap-1 rounded-xl px-3 py-1.5 text-xs font-semibold text-white"
          style={{ background: 'var(--accent)' }}
        >
          <Plus className="size-3.5" />
          Add product
        </button>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
            className="rounded-2xl p-4 space-y-3"
            style={glass.card}
          >
            <p className="display font-bold text-sm" style={{ color: 'var(--ink)' }}>New product</p>
            <div className="rounded-xl p-3" style={glass.inner}>
              <label className="text-xs font-semibold mb-1 block" style={{ color: 'var(--muted)' }}>Product name</label>
              <input
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. TikTok 1000 Coins"
                className="w-full bg-transparent text-sm outline-none"
                style={{ color: 'var(--ink)' }}
              />
            </div>
            <div className="rounded-xl p-3" style={glass.inner}>
              <label className="text-xs font-semibold mb-1 block" style={{ color: 'var(--muted)' }}>Platform</label>
              <input
                value={platform}
                onChange={e => setPlatform(e.target.value)}
                placeholder="e.g. Poppo Live, TikTok, Bigo Live..."
                className="w-full bg-transparent text-sm outline-none"
                style={{ color: 'var(--ink)' }}
              />
            </div>
            <div className="rounded-xl p-3" style={glass.inner}>
              <label className="text-xs font-semibold mb-1 block" style={{ color: 'var(--muted)' }}>Price (USDC)</label>
              <input
                type="number"
                value={price}
                onChange={e => setPrice(e.target.value)}
                placeholder="e.g. 5.00"
                className="w-full bg-transparent text-sm outline-none"
                style={{ color: 'var(--ink)' }}
              />
            </div>
            <button
              disabled={!name.trim() || !platform.trim() || !price || isAdding}
              onClick={handleAdd}
              className="w-full rounded-xl py-3 text-sm font-semibold disabled:opacity-40"
              style={{ background: 'var(--accent)', color: '#0d1b2f' }}
            >
              {isAdding ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" /> Adding...</span> : 'Add product'}
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {count === 0 && !showForm && (
        <section className="rounded-3xl p-6 text-center" style={glass.card}>
          <Package className="mx-auto mb-3 size-8" style={{ color: 'var(--subtle)' }} />
          <p className="font-semibold" style={{ color: 'var(--ink)' }}>No products</p>
          <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>Add your first product above.</p>
        </section>
      )}

      {productIds.map(id => (
        <AdminProductRow
          key={id.toString()}
          productId={id}
          contractAddress={contractAddress}
          contractAbi={contractAbi}
          wrongChain={wrongChain}
          onSwitchChain={onSwitchChain}
        />
      ))}
    </div>
  )
}

const PLATFORMS = ['TikTok', 'Bigo Live', 'Free Fire', 'Mobile Legends', 'PUBG Mobile', 'Snapchat', 'Poppo Live', 'LiveMe', 'Kick', 'Clapper', 'Tango', 'Other']

function AdminProductRow({ productId, contractAddress, contractAbi, wrongChain, onSwitchChain }: {
  productId: bigint
  contractAddress: `0x${string}`
  contractAbi: readonly object[]
  wrongChain: boolean
  onSwitchChain: () => void
}) {
  const [editing, setEditing] = useState(false)
  const [editName, setEditName] = useState('')
  const [editPlatform, setEditPlatform] = useState('')
  const [editPrice, setEditPrice] = useState('')

  const { data: raw, refetch } = useReadContract({
    address: contractAddress,
    abi: contractAbi,
    functionName: 'getProduct',
    args: [productId],
    chainId: ARC_TESTNET_ID,
  })

  const { writeContract: update, data: updateHash, isPending: updatePending } = useWriteContract()
  const { writeContract: toggle, data: toggleHash, isPending: togglePending } = useWriteContract()
  const { isLoading: updateLoading, isSuccess: updateSuccess } = useWaitForTransactionReceipt({ hash: updateHash })
  const { isLoading: toggleLoading, isSuccess: toggleSuccess } = useWaitForTransactionReceipt({ hash: toggleHash })

  if (updateSuccess) { void refetch(); setEditing(false) }
  if (toggleSuccess) void refetch()

  if (!raw) return null
  const p = raw as { id: bigint; name: string; platform: string; priceUsdc: bigint; active: boolean }
  const priceFormatted = Amount.fromRaw(p.priceUsdc, usdcFact.decimals).toFixed(2)
  const isUpdating = updatePending || updateLoading
  const isToggling = togglePending || toggleLoading

  const openEdit = () => {
    setEditName(p.name)
    setEditPlatform(p.platform)
    setEditPrice(priceFormatted)
    setEditing(e => !e)
  }

  const handleSave = () => {
    if (wrongChain) { onSwitchChain(); return }
    update({
      address: contractAddress,
      abi: contractAbi,
      functionName: 'updateProductFull',
      args: [productId, editName.trim() || p.name, editPlatform || p.platform, parseUnits(editPrice, usdcFact.decimals), p.active],
      chainId: ARC_TESTNET_ID,
    })
  }

  const handleToggle = () => {
    if (wrongChain) { onSwitchChain(); return }
    toggle({
      address: contractAddress,
      abi: contractAbi,
      functionName: 'updateProduct',
      args: [productId, p.priceUsdc, !p.active],
      chainId: ARC_TESTNET_ID,
    })
  }

  return (
    <div className="rounded-2xl overflow-hidden" style={glass.card}>
      <div className="p-4 flex items-center gap-3">
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm" style={{ color: 'var(--ink)' }}>{p.name}</p>
          <p className="text-xs" style={{ color: 'var(--muted)' }}>{p.platform} · ${priceFormatted} USDC</p>
        </div>
        <button
          onClick={openEdit}
          className="rounded-xl p-1.5 transition-all"
          style={{ background: editing ? 'var(--accent)' : 'rgba(172,198,233,0.12)', color: editing ? '#0d1b2f' : 'var(--muted)', border: '1px solid rgba(172,198,233,0.22)' }}
          title="Edit product"
        >
          <Pencil className="size-3.5" />
        </button>
        <button
          disabled={isToggling}
          onClick={handleToggle}
          className="rounded-xl px-3 py-1.5 text-xs font-semibold transition-all disabled:opacity-50"
          style={p.active
            ? { background: 'rgba(26,128,71,0.12)', color: 'var(--success)', border: '1px solid rgba(26,128,71,0.20)' }
            : { background: 'rgba(186,43,76,0.10)', color: 'var(--danger)', border: '1px solid rgba(186,43,76,0.20)' }
          }
        >
          {isToggling ? <Loader2 className="size-3.5 animate-spin" /> : p.active ? 'Active' : 'Inactive'}
        </button>
      </div>

      <AnimatePresence>
        {editing && (
          <motion.div
            initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 space-y-2">
              <p className="text-xs font-semibold" style={{ color: 'var(--muted)' }}>Edit product</p>

              {/* Name */}
              <div className="rounded-xl px-3 py-2" style={glass.inner}>
                <label className="text-xs mb-0.5 block" style={{ color: 'var(--subtle)' }}>Product name</label>
                <input
                  type="text"
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                  className="w-full bg-transparent text-sm outline-none"
                  style={{ color: 'var(--ink)' }}
                />
              </div>

              {/* Platform */}
              <div className="rounded-xl px-3 py-2" style={glass.inner}>
                <label className="text-xs mb-0.5 block" style={{ color: 'var(--subtle)' }}>Platform</label>
                <input
                  type="text"
                  value={editPlatform}
                  onChange={e => setEditPlatform(e.target.value)}
                  className="w-full bg-transparent text-sm outline-none"
                  placeholder="e.g. Poppo Live, Bigo Live, TikTok..."
                  style={{ color: 'var(--ink)' }}
                />
              </div>

              {/* Price */}
              <div className="rounded-xl px-3 py-2" style={glass.inner}>
                <label className="text-xs mb-0.5 block" style={{ color: 'var(--subtle)' }}>Price (USDC)</label>
                <input
                  type="number"
                  value={editPrice}
                  onChange={e => setEditPrice(e.target.value)}
                  placeholder="e.g. 5.00"
                  className="w-full bg-transparent text-sm outline-none"
                  style={{ color: 'var(--ink)' }}
                />
              </div>

              {/* Actions */}
              <div className="flex gap-2 pt-1">
                <button
                  disabled={!editName.trim() || !editPrice || isUpdating}
                  onClick={handleSave}
                  className="flex-1 flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-semibold disabled:opacity-40"
                  style={{ background: 'var(--accent)', color: '#0d1b2f' }}
                >
                  {isUpdating ? <Loader2 className="size-4 animate-spin" /> : <Check className="size-4" />}
                  Save changes
                </button>
                <button
                  onClick={() => setEditing(false)}
                  className="rounded-xl px-4 py-2.5"
                  style={{ background: 'rgba(172,198,233,0.12)', color: 'var(--muted)', border: '1px solid rgba(172,198,233,0.20)' }}
                >
                  <X className="size-4" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
