import { useState, useEffect, useRef } from 'react'
import { useAccount, useReadContract, useWriteContract, useWaitForTransactionReceipt, useSwitchChain } from 'wagmi'
import { erc20Abi } from 'viem'
import { ConnectKitButton } from 'connectkit'
import { ShoppingCart, CheckCircle, ExternalLink, Loader2, AlertCircle, Clock } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { getUsdc, buildTxExplorerUrl } from '@/onchain-facts'
import { Amount } from '@/onchain-money'
import { notifyNewOrder } from '@/telegram'

const ARC_TESTNET_ID = 5042002
const usdcFact = getUsdc(ARC_TESTNET_ID)!

const glass = {
  card: {
    background: 'rgba(26,47,74,0.80)',
    backdropFilter: 'blur(24px) saturate(160%)',
    WebkitBackdropFilter: 'blur(24px) saturate(160%)',
    border: '1px solid rgba(172,198,233,0.22)',
    boxShadow: '0 8px 40px rgba(0,0,0,0.40), inset 0 1px 0 rgba(172,198,233,0.10)',
  } as React.CSSProperties,
  inner: {
    background: 'rgba(13,27,47,0.60)',
    border: '1px solid rgba(172,198,233,0.18)',
  } as React.CSSProperties,
}

const spectral = 'linear-gradient(90deg, #5fbeff, #af8ff4, #f05c6b, #ffcd83, #7ef1b3)'

// Platform color map
const platformColors: Record<string, string> = {
  TikTok: '#e2e8f0',
  'Bigo Live': '#4ade80',
}

const platformBg: Record<string, string> = {
  TikTok: 'rgba(172,198,233,0.14)',
  'Bigo Live': 'rgba(0,199,60,0.18)',
}

export interface Product {
  id: bigint
  name: string
  platform: string
  priceUsdc: bigint
  active: boolean
}

interface OrderSheetProps {
  product: Product
  contractAddress: `0x${string}`
  contractAbi: readonly object[]
  usdcBalance: bigint | undefined
  onClose: () => void
  onSuccess: () => void
}

function OrderSheet({ product, contractAddress, contractAbi, usdcBalance, onClose, onSuccess }: OrderSheetProps) {
  const { address, chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const wrongChain = chainId !== ARC_TESTNET_ID

  const [accountId, setAccountId] = useState('')
  const [step, setStep] = useState<'form' | 'confirm' | 'approve' | 'order' | 'done'>('form')
  // Extract base coin count from product name (e.g. "PUBG Mobile 60 UC" → 60)
  const baseCoins = (() => { const m = product.name.match(/(\d+[\d,]*)/); return m ? parseInt(m[1].replace(/,/g, '')) : 1 })()
  // Fixed presets: 1x, 2x, 5x, 10x, 20x of the base
  const PRESETS = [1, 2, 5, 10]
  const [selectedPreset, setSelectedPreset] = useState(1)

  const quantity = selectedPreset
  const totalPrice = product.priceUsdc * BigInt(quantity)
  const priceFormatted = Amount.fromRaw(totalPrice, usdcFact.decimals).toFixed(2)
  const basePriceFormatted = Amount.fromRaw(product.priceUsdc, usdcFact.decimals).toFixed(2)
  const actualCoins = baseCoins * quantity
  const insufficientBalance = usdcBalance !== undefined && usdcBalance < totalPrice

  // Read allowance
  const { data: allowance, refetch: refetchAllowance } = useReadContract({
    address: usdcFact.address as `0x${string}`,
    abi: erc20Abi,
    functionName: 'allowance',
    args: address ? [address, contractAddress] : undefined,
    chainId: ARC_TESTNET_ID,
    query: { enabled: !!address },
  })

  const needsApproval = allowance !== undefined ? allowance < totalPrice : true
  const orderTriggeredRef = useRef(false)

  // Approve
  const { writeContract: approve, data: approveHash, isPending: approvePending } = useWriteContract()
  const { isLoading: approveConfirming, isSuccess: approveSuccess } = useWaitForTransactionReceipt({ hash: approveHash })

  // Place order
  const { writeContract: placeOrder, data: orderHash, isPending: orderPending } = useWriteContract()
  const { isLoading: orderConfirming, isSuccess: orderSuccess } = useWaitForTransactionReceipt({ hash: orderHash })

  const handleApprove = () => {
    if (wrongChain) { switchChain({ chainId: ARC_TESTNET_ID }); return }
    approve({
      address: usdcFact.address as `0x${string}`,
      abi: erc20Abi,
      functionName: 'approve',
      args: [contractAddress, totalPrice],
      chainId: ARC_TESTNET_ID,
    })
    setStep('approve')
  }

  const handleOrder = async () => {
    if (wrongChain) { switchChain({ chainId: ARC_TESTNET_ID }); return }
    await refetchAllowance()
    placeOrder({
      address: contractAddress,
      abi: contractAbi,
      functionName: 'placeOrder',
      args: [product.id, quantity > 1 ? `${accountId} [${actualCoins} coins]` : accountId, BigInt(quantity)],
      chainId: ARC_TESTNET_ID,
    })
    setStep('order')
  }

  useEffect(() => {
    if (approveSuccess && step === 'approve' && !orderTriggeredRef.current) {
      orderTriggeredRef.current = true
      void handleOrder()
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [approveSuccess, step])

  useEffect(() => {
    if (orderSuccess && step === 'order') {
      setStep('done')
      onSuccess()
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderSuccess, step])

  useEffect(() => {
    if (orderSuccess) {
      void notifyNewOrder({
        orderId: String(Date.now()).slice(-5),
        platform: product.platform,
        coins: actualCoins,
        accountId,
        amountUsdc: priceFormatted,
      })
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [orderSuccess])

  const isLoading = approvePending || approveConfirming || orderPending || orderConfirming

  return (
    <motion.div
      className="fixed inset-0 flex items-end justify-center"
      style={{ zIndex: 200 }}
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <div className="absolute inset-0 bg-black/25 backdrop-blur-sm" style={{ zIndex: -1 }} />
      <motion.section
        className="relative w-full max-w-md overflow-hidden rounded-t-3xl"
        style={{ background: 'rgba(10,28,54,0.97)', backdropFilter: 'blur(40px) saturate(180%)', WebkitBackdropFilter: 'blur(40px) saturate(180%)', border: '1px solid rgba(100,160,255,0.18)', borderBottom: 'none' }}
        initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="h-1" style={{ background: spectral }} />
        <div className="flex justify-center pt-3 pb-1">
          <div className="h-1 w-10 rounded-full bg-white/20" />
        </div>

        <div className="px-5 pb-8 pt-3">
          {step === 'confirm' ? (
            <div className="py-2">
              <p className="display text-lg font-bold text-white mb-1">Confirm your details</p>
              <p className="text-xs text-blue-300 mb-5">Once you pay this cannot be changed. Make sure everything is correct.</p>

              {/* Summary card */}
              <div className="rounded-2xl p-4 mb-4 space-y-3" style={{ background: 'rgba(255,255,255,0.06)', border: '1.5px solid rgba(100,160,255,0.2)' }}>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-blue-300 font-semibold">Platform</span>
                  <span className="text-sm text-white font-bold">{product.platform}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-blue-300 font-semibold">Coins</span>
                  <span className="text-sm text-white font-bold">{actualCoins} coins</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-blue-300 font-semibold">Account ID</span>
                  <span className="text-sm text-white font-bold break-all text-right max-w-[60%]">{accountId}</span>
                </div>
                <div className="border-t pt-3" style={{ borderColor: 'rgba(100,160,255,0.15)' }}>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-blue-300 font-semibold">Total</span>
                    <span className="text-lg text-white font-bold">${priceFormatted} USDC</span>
                  </div>
                </div>
              </div>

              <div className="mb-4 flex items-start gap-2 rounded-xl px-3 py-2.5" style={{ background: 'rgba(234,179,8,0.1)', border: '1px solid rgba(234,179,8,0.3)' }}>
                <span className="text-yellow-400 text-sm mt-0.5">⚠</span>
                <p className="text-xs text-yellow-200">Coins will be sent to <strong>"{accountId}"</strong>. If this is wrong, go back and fix it now.</p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setStep('form')}
                  className="flex-1 rounded-2xl py-3.5 text-sm font-semibold"
                  style={{ background: 'rgba(255,255,255,0.07)', color: '#93c5fd', border: '2px solid rgba(100,160,255,0.25)' }}
                >
                  Go back &amp; edit
                </button>
                <button
                  onClick={() => { if (needsApproval) { handleApprove() } else { void handleOrder() } }}
                  className="flex-1 rounded-2xl py-3.5 text-sm font-semibold transition-all hover:scale-[1.01] active:scale-[0.99]"
                  style={{ background: 'var(--accent)', color: '#0d1b2f' }}
                >
                  {needsApproval
                    ? approvePending || approveConfirming
                      ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" /> Approving...</span>
                      : `Allow $${priceFormatted} USDC`
                    : orderPending || orderConfirming
                      ? <span className="flex items-center justify-center gap-2"><Loader2 className="size-4 animate-spin" /> Placing order...</span>
                      : `Pay $${priceFormatted} USDC`}
                </button>
              </div>
            </div>
          ) : step === 'done' ? (
            <div className="text-center py-4">
              <div className="mx-auto mb-4 flex size-14 items-center justify-center rounded-full" style={{ background: 'rgba(26,128,71,0.10)' }}>
                <CheckCircle className="size-7 text-emerald-600" />
              </div>
              <p className="display text-xl font-bold mb-1 text-white">Order placed!</p>
              <p className="text-sm mb-4 text-blue-200">Your {product.platform} top-up ({quantity > 1 ? `${quantity}× ` : ''}{product.name}) is being processed. You'll receive it shortly.</p>
              {orderHash && (
                <a
                  href={buildTxExplorerUrl(ARC_TESTNET_ID, orderHash)}
                  target="_blank" rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600"
                >
                  View on explorer <ExternalLink className="size-3" />
                </a>
              )}
              <button onClick={onClose} className="mt-5 w-full rounded-2xl py-3.5 text-sm font-semibold text-white" style={{ background: 'var(--accent)' }}>
                Done
              </button>
            </div>
          ) : (
            <>
              <div className="mb-4 flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-xl text-lg font-bold" style={{ background: platformBg[product.platform] ?? '#f1f5f9', color: platformColors[product.platform] ?? '#1e293b' }}>
                  {product.platform.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="display font-bold text-white">{product.name}</p>
                  <p className="text-xs text-blue-300">{product.platform}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="display text-xl font-bold tabular-nums text-white">${priceFormatted}</p>
                  {quantity > 1 && <p className="text-xs text-blue-300">{quantity}× ${basePriceFormatted}</p>}
                  {quantity === 1 && <p className="text-xs text-blue-300">USDC</p>}
                </div>
              </div>

              {/* Quantity presets */}
              <div className="mb-4">
                <p className="mb-2 text-xs font-semibold text-blue-300">How many coins do you want?</p>
                <div className="grid grid-cols-4 gap-2 mb-2">
                  {PRESETS.map(m => {
                    const coins = baseCoins * m
                    const price = Amount.fromRaw(product.priceUsdc * BigInt(m), usdcFact.decimals).toFixed(2)
                    const tooExpensive = usdcBalance !== undefined && product.priceUsdc * BigInt(m) > usdcBalance
                    const active = selectedPreset === m
                    return (
                      <button
                        key={m}
                        onClick={() => setSelectedPreset(m)}
                        disabled={isLoading || tooExpensive || step !== 'form'}
                        className="rounded-xl py-2 px-1 text-center transition-all disabled:opacity-40"
                        style={active
                          ? { background: 'var(--accent)', color: '#0d1b2f', border: '2px solid var(--accent)' }
                          : { background: 'rgba(255,255,255,0.07)', color: '#93c5fd', border: '2px solid rgba(100,160,255,0.25)' }}
                      >
                        <p className="text-xs font-bold leading-tight">{coins}</p>
                        <p className="text-[10px] leading-tight opacity-75">${price}</p>
                      </button>
                    )
                  })}
                </div>
                <p className="text-xs text-blue-300">
                  You get <span className="font-semibold text-white">{actualCoins} coins</span> &nbsp;·&nbsp; Total: <span className="font-semibold text-white">${priceFormatted} USDC</span>
                </p>
              </div>

              <div className="mb-4 rounded-2xl p-4" style={{ background: 'rgba(255,255,255,0.06)', border: '1.5px solid rgba(100,160,255,0.2)' }}>
                <label className="mb-1.5 block text-xs font-semibold text-blue-300">
                  Your {product.platform} Account ID / Username
                </label>
                <input
                  type="text"
                  value={accountId}
                  onChange={(e) => setAccountId(e.target.value)}
                  placeholder={product.platform === 'TikTok' ? 'e.g. @username or UID' : 'e.g. Bigo ID or username'}
                  className="w-full bg-transparent text-sm text-white outline-none placeholder:text-blue-400/50"
                  disabled={isLoading}
                />
              </div>

              <div className="mb-5 flex items-center gap-2 rounded-xl px-3 py-2.5" style={{ background: 'rgba(59,130,246,0.12)', border: '1px solid rgba(100,160,255,0.2)' }}>
                <Clock className="size-3.5 shrink-0 text-blue-400" />
                <p className="text-xs text-blue-300">USDC goes into escrow. Delivery confirmed by admin, or you can cancel after 7 hours.</p>
              </div>

              {insufficientBalance && (
                <div className="mb-3 flex items-center gap-2 rounded-xl px-3 py-2.5" style={{ background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.3)' }}>
                  <AlertCircle className="size-3.5 shrink-0 text-red-400" />
                  <p className="text-xs text-red-300">Insufficient balance — you need ${priceFormatted} USDC but your wallet has ${Amount.fromRaw(usdcBalance, usdcFact.decimals).toFixed(2)}</p>
                </div>
              )}
              <button
                disabled={!accountId.trim() || isLoading || wrongChain || insufficientBalance}
                onClick={() => wrongChain ? switchChain({ chainId: ARC_TESTNET_ID }) : setStep('confirm')}
                className="w-full rounded-2xl py-3.5 text-sm font-semibold transition-all hover:scale-[1.01] active:scale-[0.99] disabled:cursor-not-allowed disabled:opacity-40"
                style={{ background: insufficientBalance ? 'rgba(239,68,68,0.25)' : 'var(--accent)', color: insufficientBalance ? '#fca5a5' : '#0d1b2f', border: insufficientBalance ? '1.5px solid rgba(239,68,68,0.4)' : 'none' }}
              >
                {wrongChain ? 'Switch to Arc Testnet' : insufficientBalance ? 'Not enough USDC' : `Review & Pay $${priceFormatted} USDC`}
              </button>
            </>
          )}
        </div>
      </motion.section>
    </motion.div>
  )
}

interface StoreFrontProps {
  contractAddress: `0x${string}` | null
  contractAbi: readonly object[]
}

export default function StoreFront({ contractAddress, contractAbi }: StoreFrontProps) {
  const { address } = useAccount()
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [showOrders, setShowOrders] = useState(false)

  // Read product count
  const { data: productCount } = useReadContract({
    address: contractAddress ?? undefined,
    abi: contractAbi,
    functionName: 'productCount',
    chainId: ARC_TESTNET_ID,
    query: { enabled: !!contractAddress },
  })

  // Read USDC balance
  const { data: usdcBalance, refetch: refetchBalance } = useReadContract({
    address: usdcFact.address as `0x${string}`,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    chainId: ARC_TESTNET_ID,
    query: { enabled: !!address },
  })

  const balanceFormatted = usdcBalance
    ? Amount.fromRaw(usdcBalance, usdcFact.decimals).toFixed(2)
    : null

  const count = productCount ? Number(productCount) : 0

  // Read products (up to 12)
  const productIds = Array.from({ length: Math.min(count, 12) }, (_, i) => i + 1)

  return (
    <div className="relative min-h-dvh overflow-hidden" style={{ background: 'var(--bg-gradient)' }}>
      {/* Ambient blobs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div style={{ position: 'absolute', top: '6%', left: '4%', width: 340, height: 340, borderRadius: '50%', background: 'radial-gradient(circle, rgba(172,198,233,0.18) 0%, transparent 70%)', filter: 'blur(80px)' }} />
        <div style={{ position: 'absolute', bottom: '10%', right: '5%', width: 280, height: 280, borderRadius: '50%', background: 'radial-gradient(circle, rgba(95,190,255,0.12) 0%, transparent 70%)', filter: 'blur(70px)' }} />
        <div style={{ position: 'absolute', top: '45%', right: '20%', width: 200, height: 200, borderRadius: '50%', background: 'radial-gradient(circle, rgba(175,143,244,0.10) 0%, transparent 70%)', filter: 'blur(60px)' }} />
      </div>

      <div className="relative z-10 mx-auto max-w-md px-4 pb-32 pt-6">
        {/* Header */}
        <header className="mb-6 flex items-center justify-between">
          <div>
            <p className="display text-xl font-bold" style={{ color: 'var(--ink)' }}>TopUp Pay</p>
            <p className="text-xs" style={{ color: 'var(--subtle)' }}>Social coins with USDC</p>
          </div>
          <ConnectKitButton.Custom>
            {({ isConnected, show, address: addr }) => (
              <button
                onClick={show}
                className="rounded-full px-4 py-2 text-xs font-semibold transition-all hover:scale-[1.02]"
                style={{ background: 'var(--accent)', color: '#0d1b2f', border: '1px solid rgba(172,198,233,0.40)' }}
              >
                {isConnected && addr ? `${addr.slice(0, 6)}…${addr.slice(-4)}` : 'Connect Wallet'}
              </button>
            )}
          </ConnectKitButton.Custom>
        </header>

        {/* Balance card */}
        {address && (
          <section className="mb-4 rounded-3xl p-5" style={glass.card}>
            <div className="mb-1 flex items-center gap-1.5">
              <span className="text-xs font-semibold tracking-wide" style={{ color: 'var(--muted)', letterSpacing: '0.06em' }}>USDC BALANCE</span>
            </div>
            <div className="flex items-baseline gap-1.5">
              <span className="display text-4xl font-bold tabular-nums" style={{ color: 'var(--ink)' }}>
                {balanceFormatted ?? '—'}
              </span>
              <span className="text-base font-medium" style={{ color: 'var(--subtle)' }}>USDC</span>
            </div>
            <p className="mt-1 text-xs" style={{ color: 'var(--muted)' }}>Arc Testnet · {count} products available</p>
          </section>
        )}

        {/* No contract yet */}
        {!contractAddress && (
          <section className="rounded-3xl p-6 text-center" style={glass.card}>
            <AlertCircle className="mx-auto mb-3 size-8" style={{ color: 'var(--subtle)' }} />
            <p className="display font-bold mb-1" style={{ color: 'var(--ink)' }}>Contract not deployed yet</p>
            <p className="text-sm" style={{ color: 'var(--muted)' }}>Deploy the SocialTopUp contract to start selling coins.</p>
          </section>
        )}

        {/* Products grid */}
        {contractAddress && count === 0 && (
          <section className="rounded-3xl p-6 text-center" style={glass.card}>
            <ShoppingCart className="mx-auto mb-3 size-8" style={{ color: 'var(--subtle)' }} />
            <p className="display font-bold mb-1" style={{ color: 'var(--ink)' }}>No products yet</p>
            <p className="text-sm" style={{ color: 'var(--muted)' }}>Switch to Admin to add your first product.</p>
          </section>
        )}

        {contractAddress && count > 0 && (
          <div className="space-y-3">
            <p className="text-xs font-semibold tracking-widest" style={{ color: 'var(--muted)', letterSpacing: '0.08em' }}>AVAILABLE NOW</p>
            <div className="grid grid-cols-1 gap-3">
              {productIds.map((id) => (
                <ProductCard
                  key={id}
                  productId={BigInt(id)}
                  contractAddress={contractAddress}
                  contractAbi={contractAbi}
                  onBuy={(p) => setSelectedProduct(p)}
                />
              ))}
            </div>
          </div>
        )}

        {/* My Orders collapsible */}
        {address && contractAddress && (
          <div className="mt-6">
            <button
              onClick={() => setShowOrders(v => !v)}
              className="flex w-full items-center justify-between rounded-2xl px-4 py-3 text-sm font-semibold transition-all"
              style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(100,160,255,0.18)', color: 'var(--ink)' }}
            >
              <span className="flex items-center gap-2">
                <span>📋</span> My Orders
              </span>
              <span className="text-xs" style={{ color: 'var(--muted)' }}>{showOrders ? '▲ Hide' : '▼ Show'}</span>
            </button>
            <AnimatePresence>
              {showOrders && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.25 }}
                  className="overflow-hidden"
                >
                  <MyOrders address={address} contractAddress={contractAddress} contractAbi={contractAbi} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Order sheet */}
      <AnimatePresence>
        {selectedProduct && contractAddress && (
          <OrderSheet
            product={selectedProduct}
            contractAddress={contractAddress}
            contractAbi={contractAbi}
            usdcBalance={usdcBalance}
            onClose={() => setSelectedProduct(null)}
            onSuccess={() => { setSelectedProduct(null); void refetchBalance() }}
          />
        )}
      </AnimatePresence>
    </div>
  )
}

function ProductCard({
  productId,
  contractAddress,
  contractAbi,
  onBuy,
}: {
  productId: bigint
  contractAddress: `0x${string}`
  contractAbi: readonly object[]
  onBuy: (p: Product) => void
}) {
  const { data: raw } = useReadContract({
    address: contractAddress,
    abi: contractAbi,
    functionName: 'getProduct',
    args: [productId],
    chainId: ARC_TESTNET_ID,
  })

  if (!raw) return null
  const p = raw as Product
  if (!p.active) return null

  const priceFormatted = Amount.fromRaw(p.priceUsdc, usdcFact.decimals).toFixed(2)

  return (
    <motion.button
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      onClick={() => onBuy(p)}
      className="w-full rounded-2xl p-4 text-left transition-shadow"
      style={glass.card}
    >
      <div className="flex items-center gap-3">
        <div
          className="flex size-11 shrink-0 items-center justify-center rounded-xl text-base font-bold"
          style={{ background: platformBg[p.platform] ?? 'var(--surface-muted)', color: platformColors[p.platform] ?? 'var(--ink)' }}
        >
          {p.platform.charAt(0)}
        </div>
        <div className="flex-1 min-w-0">
          <p className="display font-bold truncate" style={{ color: 'var(--ink)' }}>{p.name}</p>
          <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{p.platform}</p>
        </div>
        <div className="text-right shrink-0">
          <p className="display text-lg font-bold tabular-nums" style={{ color: 'var(--ink)' }}>${priceFormatted}</p>
          <p className="text-xs" style={{ color: 'var(--subtle)' }}>USDC</p>
        </div>
      </div>
    </motion.button>
  )
}

type OrderStatus = 0 | 1 | 2
const STATUS_LABEL: Record<OrderStatus, string> = { 0: 'Pending', 1: 'Delivered', 2: 'Refunded' }
const STATUS_COLOR: Record<OrderStatus, string> = {
  0: 'rgba(251,191,36,0.15)',
  1: 'rgba(34,197,94,0.15)',
  2: 'rgba(100,116,139,0.15)',
}
const STATUS_TEXT: Record<OrderStatus, string> = { 0: '#fbbf24', 1: '#4ade80', 2: '#94a3b8' }

function MyOrders({ address, contractAddress, contractAbi }: { address: string; contractAddress: `0x${string}`; contractAbi: readonly object[] }) {
  const { data: orderIds } = useReadContract({
    address: contractAddress,
    abi: contractAbi,
    functionName: 'getOrdersByBuyer',
    args: [address as `0x${string}`],
    chainId: ARC_TESTNET_ID,
  })

  const ids = (orderIds as bigint[] | undefined) ?? []

  if (ids.length === 0) {
    return (
      <div className="mt-2 rounded-2xl px-4 py-5 text-center" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(100,160,255,0.12)' }}>
        <p className="text-sm" style={{ color: 'var(--muted)' }}>No orders yet — buy something above!</p>
      </div>
    )
  }

  return (
    <div className="mt-2 space-y-2">
      {[...ids].reverse().map(id => (
        <OrderRow key={String(id)} orderId={id} contractAddress={contractAddress} contractAbi={contractAbi} />
      ))}
    </div>
  )
}

function OrderRow({ orderId, contractAddress, contractAbi }: { orderId: bigint; contractAddress: `0x${string}`; contractAbi: readonly object[] }) {
  const { data: raw } = useReadContract({
    address: contractAddress,
    abi: contractAbi,
    functionName: 'getOrder',
    args: [orderId],
    chainId: ARC_TESTNET_ID,
  })

  if (!raw) return null
  const order = raw as { id: bigint; buyer: string; productId: bigint; amount: bigint; status: number; createdAt: bigint; buyerAccountId: string }
  const status = order.status as OrderStatus
  const amountFormatted = Amount.fromRaw(order.amount, usdcFact.decimals).toFixed(2)
  const date = new Date(Number(order.createdAt) * 1000).toLocaleDateString()

  return (
    <div className="rounded-2xl px-4 py-3 flex items-center gap-3" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(100,160,255,0.12)' }}>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold truncate" style={{ color: 'var(--ink)' }}>{order.buyerAccountId}</p>
        <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>${amountFormatted} USDC · {date}</p>
      </div>
      <span className="shrink-0 rounded-full px-2.5 py-1 text-xs font-bold" style={{ background: STATUS_COLOR[status], color: STATUS_TEXT[status] }}>
        {STATUS_LABEL[status]}
      </span>
    </div>
  )
}
