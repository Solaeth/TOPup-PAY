// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

contract SocialTopUp is Ownable, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    error ZeroAddress();
    error ProductNotFound(uint256 productId);
    error ProductInactive(uint256 productId);
    error InvalidPrice();
    error OrderNotFound(uint256 orderId);
    error OrderNotPending(uint256 orderId);
    error OrderNotExpired(uint256 orderId);
    error RenounceOwnershipWhilePaused();

    enum OrderStatus {
        Pending,
        Delivered,
        Refunded
    }

    struct Product {
        uint256 id;
        string name;
        string platform;
        uint256 priceUsdc;
        bool active;
    }

    struct Order {
        uint256 id;
        address buyer;
        uint256 productId;
        uint256 amount;
        OrderStatus status;
        uint256 createdAt;
        string buyerAccountId;
    }

    uint256 public constant CANCEL_DEADLINE = 7 hours;

    IERC20 public immutable usdc;
    address public treasury;

    mapping(uint256 => Product) private _products;
    mapping(uint256 => Order) private _orders;
    mapping(address => uint256[]) private _ordersByBuyer;

    uint256 private _productCount;
    uint256 private _orderCount;

    event ProductAdded(uint256 indexed id, string name, string platform, uint256 priceUsdc);
    event ProductUpdated(uint256 indexed id, uint256 newPrice, bool active);
    event TreasuryUpdated(address indexed previousTreasury, address indexed newTreasury);
    event OrderPlaced(
        uint256 indexed orderId,
        address indexed buyer,
        uint256 indexed productId,
        uint256 amount,
        string buyerAccountId
    );
    event OrderDelivered(uint256 indexed orderId);
    event OrderRefunded(uint256 indexed orderId);

    constructor(address initialOwner, address usdcAddress, address treasury_) Ownable(initialOwner) {
        if (initialOwner == address(0) || usdcAddress == address(0) || treasury_ == address(0)) {
            revert ZeroAddress();
        }

        usdc = IERC20(usdcAddress);
        treasury = treasury_;
    }

    error InvalidQuantity();

    function placeOrder(uint256 productId, string calldata buyerAccountId, uint256 quantity) external whenNotPaused nonReentrant {
        if (quantity == 0) revert InvalidQuantity();
        Product memory product = _products[productId];
        if (product.id == 0) revert ProductNotFound(productId);
        if (!product.active) revert ProductInactive(productId);

        uint256 totalAmount = product.priceUsdc * quantity;

        _orderCount++;
        uint256 newOrderId = _orderCount;

        _orders[newOrderId] = Order({
            id: newOrderId,
            buyer: msg.sender,
            productId: productId,
            amount: totalAmount,
            status: OrderStatus.Pending,
            createdAt: block.timestamp,
            buyerAccountId: buyerAccountId
        });

        _ordersByBuyer[msg.sender].push(newOrderId);

        usdc.safeTransferFrom(msg.sender, address(this), totalAmount);

        emit OrderPlaced(newOrderId, msg.sender, productId, totalAmount, buyerAccountId);
    }

    function confirmDelivery(uint256 orderId) external onlyOwner nonReentrant {
        Order storage order = _orders[orderId];
        if (order.id == 0) revert OrderNotFound(orderId);
        if (order.status != OrderStatus.Pending) revert OrderNotPending(orderId);

        order.status = OrderStatus.Delivered;
        usdc.safeTransfer(treasury, order.amount);

        emit OrderDelivered(orderId);
    }

    function refundOrder(uint256 orderId) external onlyOwner nonReentrant {
        Order storage order = _orders[orderId];
        if (order.id == 0) revert OrderNotFound(orderId);
        if (order.status != OrderStatus.Pending) revert OrderNotPending(orderId);

        order.status = OrderStatus.Refunded;
        usdc.safeTransfer(order.buyer, order.amount);

        emit OrderRefunded(orderId);
    }

    function cancelExpiredOrder(uint256 orderId) external nonReentrant {
        Order storage order = _orders[orderId];
        if (order.id == 0) revert OrderNotFound(orderId);
        if (order.status != OrderStatus.Pending) revert OrderNotPending(orderId);
        if (block.timestamp < order.createdAt + CANCEL_DEADLINE) revert OrderNotExpired(orderId);

        order.status = OrderStatus.Refunded;
        usdc.safeTransfer(order.buyer, order.amount);

        emit OrderRefunded(orderId);
    }

    function addProduct(string calldata name, string calldata platform, uint256 priceUsdc) external onlyOwner {
        if (priceUsdc == 0) revert InvalidPrice();

        _productCount++;
        uint256 newProductId = _productCount;

        _products[newProductId] = Product({
            id: newProductId,
            name: name,
            platform: platform,
            priceUsdc: priceUsdc,
            active: true
        });

        emit ProductAdded(newProductId, name, platform, priceUsdc);
    }

    function updateProduct(uint256 productId, uint256 newPrice, bool active) external onlyOwner {
        Product storage product = _products[productId];
        if (product.id == 0) revert ProductNotFound(productId);
        if (newPrice == 0) revert InvalidPrice();

        product.priceUsdc = newPrice;
        product.active = active;

        emit ProductUpdated(productId, newPrice, active);
    }

    function updateProductFull(
        uint256 productId,
        string calldata name,
        string calldata platform,
        uint256 newPrice,
        bool active
    ) external onlyOwner {
        Product storage product = _products[productId];
        if (product.id == 0) revert ProductNotFound(productId);
        if (newPrice == 0) revert InvalidPrice();

        product.name = name;
        product.platform = platform;
        product.priceUsdc = newPrice;
        product.active = active;

        emit ProductUpdated(productId, newPrice, active);
    }

    function setTreasury(address newTreasury) external onlyOwner {
        if (newTreasury == address(0)) revert ZeroAddress();

        address oldTreasury = treasury;
        treasury = newTreasury;

        emit TreasuryUpdated(oldTreasury, newTreasury);
    }

    function pause() external onlyOwner {
        _pause();
    }

    function unpause() external onlyOwner {
        _unpause();
    }

    function renounceOwnership() public override onlyOwner {
        if (paused()) revert RenounceOwnershipWhilePaused();
        super.renounceOwnership();
    }

    function getProduct(uint256 productId) external view returns (Product memory) {
        Product memory product = _products[productId];
        if (product.id == 0) revert ProductNotFound(productId);
        return product;
    }

    function getOrder(uint256 orderId) external view returns (Order memory) {
        Order memory order = _orders[orderId];
        if (order.id == 0) revert OrderNotFound(orderId);
        return order;
    }

    function getOrdersByBuyer(address buyer) external view returns (uint256[] memory) {
        return _ordersByBuyer[buyer];
    }

    function productCount() external view returns (uint256) {
        return _productCount;
    }

    function orderCount() external view returns (uint256) {
        return _orderCount;
    }
}
